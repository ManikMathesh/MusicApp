import XCTest
@testable import Music

class WebViewViewControllerTest: XCTestCase {

    var storyboard: UIStoryboard!
    var sut: WebViewViewController!
    
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        storyboard = UIStoryboard(name: "Main", bundle: nil)
        sut = storyboard.instantiateViewController(withIdentifier: "WebViewViewController") as? WebViewViewController
        sut.loadViewIfNeeded()
        
        // Act
        
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        storyboard = nil
        sut = nil
    }

    func test_WebViewViewController_WhenCreated_HasWebViewProperty() throws {
        // Arrange
        // Act
        
        // Assert
        let webView = try XCTUnwrap(sut.webView, "WebView is not created") 
        XCTAssertNotNil(webView, "WebView is not created")
    }
    
    func test_WebViewViewController_WhenCreated_HasActivityIndicatorProperty() throws {
        // Arrange
        // Act
        
        // Assert
        let spinner = try XCTUnwrap(sut.activityIndicator, "ActivityIndicator is not created")
        XCTAssertNotNil(spinner, "ActivityIndicator is not created")
    }
    
}
