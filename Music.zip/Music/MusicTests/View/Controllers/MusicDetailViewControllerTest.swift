import XCTest
@testable import Music

class MusicDetailViewControllerTest: XCTestCase {

    var storyboard: UIStoryboard!
    var sut: MusicDetailViewController!
    
    var cellID: String!
    var musicDetailcell: MusicDetailCell!
    var indexPath_One: IndexPath!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        storyboard = UIStoryboard(name: "Main", bundle: nil)
        sut = storyboard.instantiateViewController(withIdentifier: "MusicDetailViewController") as? MusicDetailViewController
        sut.loadViewIfNeeded()
        
        // Act
        indexPath_One = IndexPath(row: 1, section: 0)
        musicDetailcell =  sut.tableView.dataSource?.tableView(sut.tableView, cellForRowAt: indexPath_One) as? MusicDetailCell
        
        cellID = "MusicDetailCellID"
       // musicDetailcell = MusicDetailCell(style: .default, reuseIdentifier: cellID)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        storyboard = nil
        sut = nil
        musicDetailcell = nil
        cellID = nil
        indexPath_One = nil
    }

    func test_MusicDetailViewController_WhenCreated_HasTableViewProperty() throws {
        // Arrange
        // Act
        
        // Assert
        let tableView = try XCTUnwrap(sut.tableView, "TableView is not connected to IBOutlet") 
        XCTAssertNotNil(tableView, "TableView is not created")
    }
    
    func test_MusicDetailViewController_WhenCreated_RegisterCustomTableViewCell() {
        
        sut.viewDidLoad()
        XCTAssertNotNil(musicDetailcell,"TableView doesn't have a cell with MusicDetailCellID")
        XCTAssertEqual(musicDetailcell?.reuseIdentifier, "MusicDetailCellID", "TableView doesn't have a cell with MusicCellID")
      
    }
    
    func test_MusicDetailViewController_WhenMusicDetailCellCreated_ShouldCreatePropertiesWithEmptyValues() {
        // Arrange

        // Act
        
        // Assert
        XCTAssertEqual(musicDetailcell?.trackNameLabel.text, "")
        XCTAssertEqual(musicDetailcell?.artistLabel.text, "")
        XCTAssertEqual(musicDetailcell?.priceLabel.text, "")
        XCTAssertEqual(musicDetailcell?.durationLabel.text, "")
        XCTAssertEqual(musicDetailcell?.releaseDateLabel.text, "")

    }
    
    func test_MusicDetailViewController_WhenCreated_ShouldCreateObjectForViewModel() {
              
        XCTAssertNotNil(sut.viewModel)
    }
    
    
    
    func test_MusicDetailViewController_WhenMusicDataAvailable_ShouldUpdateTheMusicDetailCellProperties() throws {
    // Arrange
        let appManager = AppManager()
        let musicDetails: MusicTableViewCellViewModel = MusicTableViewCellViewModel(trackName: "Don't Stop Believin'", artistName: "Journey", trackPrice: 1.29, currency: "USD", artworkUrl30: "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/30x30bb.jpg", artworkUrl60: "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/60x60bb.jpg", artworkUrl100: "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/100x100bb.jpg", releaseDate: appManager.getDateFromString(dateString: "1981-06-03T07:00:00Z"), trackTimeMillis: 250880, trackViewUrl: "https://music.apple.com/us/album/dont-stop-believin/169003304?i=169003415&uo=4")
               
    // Act
        musicDetailcell.updateData(musicDetails: musicDetails)
        
    // Assert
        XCTAssertEqual(musicDetailcell.trackNameLabel.text, "Don't Stop Believin'", "MusicDetailCell - trackNameLabel value is not correct")
        XCTAssertEqual(musicDetailcell.artistLabel.text, "Journey", "MusicDetailCell - artistLabel value is not correct")
        XCTAssertEqual(musicDetailcell.priceLabel.text, "$1.29", "MusicDetailCell - priceLabel value is not correct")
        XCTAssertEqual(musicDetailcell.durationLabel.text, "Duration: 4.18", "MusicDetailCell - durationLabel value is not correct")
        XCTAssertEqual(musicDetailcell.releaseDateLabel.text, "Release date: Jun 3, 1981", "MusicDetailCell - releaseDateLabel value is not correct")

        
    }
    
    
    func test_MusicDetailViewController_WhenArtworkImageViewCellCreated_ShouldCreatePropertiesWithEmptyValues() {
        // Arrange
        
        // Act
        let cell = ArtworkImageViewCell(style: .default, reuseIdentifier: cellID)

        // Assert
        XCTAssertNil(cell.trackImageView.image)
    }
    
    
    func test_MusicDetailViewController_WhenCreated_HasMoreDetailsButtonAndAction() throws{
        
        let moreDetailsButton = try XCTUnwrap(sut.moreDetailsButton, "moreDetailsButton doesn't have a refencing outlet")
        
        let moreDetailsButtonActions = try XCTUnwrap(moreDetailsButton.actions(forTarget: sut, forControlEvent: .touchUpInside), "moreDetailsButton doesn't have any action") // Only one element added, so can assert using the count.
        
        XCTAssertEqual(moreDetailsButtonActions.count, 1)
        XCTAssertEqual(moreDetailsButtonActions.first, "moreDetailsButtonAction:", "There's no action with a name of moreDetailsButtonAction")
    }
    

}
