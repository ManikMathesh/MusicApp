import XCTest
@testable import Music

class HomeViewControllerTest: XCTestCase {

    var storyboard: UIStoryboard!
    var sut: HomeViewController!
    
    var cellID: String!
    var cell: MusicCell!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        storyboard = UIStoryboard(name: "Main", bundle: nil)
        sut = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController
        sut.loadViewIfNeeded()
        
        cellID = "MusicCellID"
        cell = MusicCell(style: .default, reuseIdentifier: cellID)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        storyboard = nil
        sut = nil
        cell = nil
        cellID = nil
    }

    func test_HomeViewController_WhenCreated_HasTableViewProperty() throws {
        // Arrange
        // Act
        
        // Assert
        let tableView = try XCTUnwrap(sut.tableView, "TableView is not connected to IBOutlet") // This will Unwrap the optional value and we can add meaningful error
        XCTAssertNotNil(tableView, "TableView is not created")
    }
    
    func test_HomeViewController_WhenCreated_RegisterCustomTableViewCell() {
        
        sut.viewDidLoad()
        XCTAssertNotNil(cell,"TableView doesn't have a cell with MusicCellID")
        XCTAssertEqual(cell?.reuseIdentifier, "MusicCellID", "TableView doesn't have a cell with MusicCellID")
      
    }
    
    func test_HomeViewController_WhenMusicCellCreated_ShouldCreateProperties() {
        // Arrange
            
        // Assert
        XCTAssertNotNil(cell.trackImageView)
        XCTAssertNotNil(cell.trackLabel)
        XCTAssertNotNil(cell.artistLabel)
        XCTAssertNotNil(cell.priceLabel)
        XCTAssertNotNil(cell.separatorView)

    }
    
    func test_HomeViewController_WhenCreated_ShouldBindToTheViewModel() {
      
        sut.bindViewModel()
        
        XCTAssertNotNil(sut.viewModel)
    }
    
    
    
    func test_HomeViewController_WhenMusicDataAvailable_ShouldUpdateTheMusicCellProperties() throws {
    // Arrange
        let musicDetails: MusicTableViewCellViewModel = MusicTableViewCellViewModel(trackName: "Don't Stop Believin'", artistName: "Journey", trackPrice: 1.29, currency: "USD", artworkUrl30: "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/30x30bb.jpg", artworkUrl60: "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/60x60bb.jpg", artworkUrl100: "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/100x100bb.jpg", releaseDate: Date(), trackTimeMillis: 250880, trackViewUrl: "https://music.apple.com/us/album/dont-stop-believin/169003304?i=169003415&uo=4")
               
    // Act
        cell.updateData(musicDetails: musicDetails)
        
    // Assert
        XCTAssertEqual(cell.trackLabel.text, "Don't Stop Believin'", "MusicCell - trackLabel value is not set")
        XCTAssertEqual(cell.artistLabel.text, "Journey", "MusicCell - artistLabel value is not set")
        XCTAssertEqual(cell.priceLabel.text, "$1.29", "MusicCell - priceLabel value is not set")
        
    }
    

}



