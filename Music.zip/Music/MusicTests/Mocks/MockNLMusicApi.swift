
import Foundation
@testable import Music

class MockNLMusicApi: NLMusicApiProtocol {
    
    var isFetchMusicApiMethodCalled: Bool = false

    func fetchMusicApi(completionHandler: @escaping (MusicResponseModel?, MusicApiError?) -> Void) {
        isFetchMusicApiMethodCalled = true
        
        guard let filePath = Bundle(for: NLMusicApiTests.self).url(forResource: "MusicApiJSONResponse", withExtension: "json"),
              let data = try? Data(contentsOf: filePath) else {
                  return completionHandler(nil, MusicApiError.invalidResponseModel)
              }
        
        let musicResponseModel = try? JSONDecoder().decode(MusicResponseModel.self, from: data)
        completionHandler(musicResponseModel, nil)
    }
}
