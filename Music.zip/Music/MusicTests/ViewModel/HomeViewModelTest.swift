import XCTest
@testable import Music

class HomeViewModelTest: XCTestCase {
    
    var mockNLMusicApi: MockNLMusicApi!
    var sut: HomeViewModel!
    var appManager: AppManager!
    
    override func setUp() {
        mockNLMusicApi = MockNLMusicApi()
        sut = HomeViewModel(musicApi: mockNLMusicApi)
        appManager = AppManager()
    }
    
    override func tearDown() {
        mockNLMusicApi = nil
        sut = nil
        appManager = nil
    }
    
    func test_HomeViewModel_WhenViewModelMakeWebServiceCallForMusicApi_ShouldCallfetchMusicApiMethod() {
        // Arrange

        // Act
        sut.makeWebServiceCallForMusicApi()
        
        // Assert
        XCTAssertTrue(mockNLMusicApi.isFetchMusicApiMethodCalled, "fetchMusicApi() is not called in NLMusicApi class")
    }
    
    func test_HomeViewModel_WhenSuccessfulApiResponse_ShouldUpdateTheMusicListPropertyObserver() {
        // Arrange
        let expectation = expectation(description: "MusicList value should be updated expectation")
        
        // Act
        sut.makeWebServiceCallForMusicApi()
        
        // Assert
        XCTAssertTrue(sut.musicList.value.count > 0, "makeWebServiceCallForMusicApi() method's success block doesn't update the value for musicList property")
        expectation.fulfill()
        
        wait(for: [expectation], timeout: 5)
    }

    
    func test_HomeViewModel_WhenViewModelMakeWebServiceCallForMusicApi_ShouldHaveTheInternetConnection() {
        //Arrange
        // Act
        
        // Assert
        XCTAssertTrue(sut.reachability.isConnectedToNetwork(), "No internet connection")
        
    }
    
    func test_HomeViewModel_WhenSortMusicDataInDescendingOrderMethodCalled_ShouldGiveSortedModelValues() {

        // Arrange
        //Input array in date format --> 1979-10-28 07:00:00 +0000  2018-12-07 08:00:00 +0000  2012-10-21 07:00:00 +0000
        
        // Act
        let sortedArray = sut.sortMusicDataInDescendingOrder(musicDetailsArray: getMusicListArray())
        
        // Assert
        
        XCTAssertEqual(sortedArray[0].releaseDate, appManager.getDateFromString(dateString: "2018-12-07T08:00:00Z"))
        XCTAssertEqual(sortedArray[1].releaseDate, appManager.getDateFromString(dateString: "2012-12-07T08:00:00Z"))
        XCTAssertEqual(sortedArray[2].releaseDate, appManager.getDateFromString(dateString: "1979-10-28T07:00:00Z"))
        
    }
    
    func getMusicListArray() -> [MusicTableViewCellViewModel] {
        
        var musicListArray = [MusicTableViewCellViewModel] ()
        
        let dateArray = ["1979-10-28T07:00:00Z","2018-12-07T08:00:00Z","2012-12-07T08:00:00Z"]
        
        for item in dateArray {
            let musicDetails: MusicTableViewCellViewModel = MusicTableViewCellViewModel(trackName: "Don't Stop Believin'", artistName: "Journey", trackPrice: 1.29, currency: "USD", artworkUrl30: "", artworkUrl60: "", artworkUrl100: "", releaseDate: appManager.getDateFromString(dateString: item), trackTimeMillis: 250880, trackViewUrl: "")
            musicListArray.append(musicDetails)
        }
        return musicListArray
    }
 
}


