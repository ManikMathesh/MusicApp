import XCTest
@testable import Music

class AppManagerTest: XCTestCase {

    private var sut:AppManager!

    
    override func setUpWithError() throws {
        sut = AppManager()
    }

    override func tearDownWithError() throws {
        sut = nil
    }

    func test_getCurrencySymbolFromCurrencyCode() {
        
        XCTAssertEqual(sut.getCurrencySymbolFromCurrencyCode(currencyCode: "USD"), "$")
        XCTAssertEqual(sut.getCurrencySymbolFromCurrencyCode(currencyCode: "GBP"), "£")
        XCTAssertEqual(sut.getCurrencySymbolFromCurrencyCode(currencyCode: "EUR"), "€")
        XCTAssertEqual(sut.getCurrencySymbolFromCurrencyCode(currencyCode: "JPY"), "¥")
        XCTAssertEqual(sut.getCurrencySymbolFromCurrencyCode(currencyCode: "AUD"), "A$")
        XCTAssertEqual(sut.getCurrencySymbolFromCurrencyCode(currencyCode: "CAD"), "CA$")
        XCTAssertEqual(sut.getCurrencySymbolFromCurrencyCode(currencyCode: "INR"), "₹")

    }
    
    func test_getDurationFromMilliSeconds() {
        
        let convertedMinutesString = String(format: "%.2f", sut.getDurationFromMilliSeconds(milliseconds: 250880.00))

        XCTAssertEqual(convertedMinutesString, "4.18")
    }
    
    func test_getDateFromString() {
        
        XCTAssertNotNil(sut.getDateFromString(dateString: "2011-01-01T12:00:00Z"), "AppManager: getDateFromString() method coudn't convert the date from string.")

    }
    
    func test_getStringFromDate_MMM_d_YYYY_Format() {
        
        XCTAssertNotNil(sut.getStringFromDate_MMM_d_YYYY_Format(from: Date()), "AppManager: getStringFromDate_MMM_d_YYYY_Format() method coudn't convert the date to String format.")

    }
    
    func test_getStringFromDate_yyyy_MM_dd_T_HH_mm_ssZ_Format() {
        
        XCTAssertNotNil(sut.getStringFromDate_yyyy_MM_dd_T_HH_mm_ssZ_Format(from: Date()), "AppManager: getStringFromDate_yyyy_MM_dd_T_HH_mm_ssZ_Format() method coudn't convert the date to String format.")
    }
    
    
    
}
