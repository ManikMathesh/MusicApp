import XCTest
@testable import Music

class NLMusicApiTests: XCTestCase {
    
    var sut: NLMusicApi!
    
    override func setUp() {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [MockURLProtocol.self]
        let urlSession = URLSession(configuration: config)
        sut = NLMusicApi(urlString: MusicSDKConstants.musicApiURL, urlSession: urlSession)
    }
    
    override func tearDown() {
        sut = nil
        MockURLProtocol.stubResponseData = nil
        MockURLProtocol.stubError = nil
    }
    
    func test_MusicWebService_WhenGivenSuccessfullResponse_ReturnsSuccess() {
        // Arrange
        let filePath = Bundle(for: NLMusicApiTests.self).url(forResource: "MusicApiJSONResponse", withExtension: "json")
        let jsonString = try? String(contentsOf: filePath!)
        MockURLProtocol.stubResponseData = jsonString?.data(using: .utf8)
        let expectation =  self.expectation(description: "Music Api Response Expectation")
        
        // Act
        sut.fetchMusicApi { musicResponseModel, error in
            
        // Assert
            XCTAssertEqual(musicResponseModel?.resultCount, 3)
            XCTAssertEqual(musicResponseModel?.results.count, 3)
            
            let musicDetails = musicResponseModel?.results[0]
            XCTAssertEqual(musicDetails?.trackName, "Don't Stop Believin'")
            XCTAssertEqual(musicDetails?.artistName, "Journey")
            XCTAssertEqual(musicDetails?.trackPrice, 1.29)
            XCTAssertEqual(musicDetails?.currency, "USD")
            XCTAssertEqual(musicDetails?.artworkUrl30, "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/30x30bb.jpg")
            XCTAssertEqual(musicDetails?.artworkUrl60, "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/60x60bb.jpg")
            XCTAssertEqual(musicDetails?.artworkUrl100, "https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/01/69/5f/01695f6c-541d-faef-ac67-d1033b11c79a/source/100x100bb.jpg")
            XCTAssertEqual(musicDetails?.releaseDate, "1981-06-03T07:00:00Z")
            XCTAssertEqual(musicDetails?.trackTimeMillis, 250880)

            expectation.fulfill()
        }
        self.wait(for: [expectation], timeout: 5)
    }
    
    
    func test_MusicWebService_WhenReceivedDifferentJSONResponse_ErrorTookPlace() {
        
        // Arrange
        let jsonString = "{\"path\":\"music\", \"error\":\"Internal Server Error\"}"
        MockURLProtocol.stubResponseData = jsonString.data(using: .utf8)
        let expectation =  self.expectation(description: "fetchMusicApi() method expectation for the response that contains a different JSON structure")
        
        // Act
        sut.fetchMusicApi { musicResponseModel, error in
            
        // Assert
            XCTAssertNil(musicResponseModel, "The response model for the request containing unknown JSON response, should have been nil")
            XCTAssertEqual(error, MusicApiError.invalidResponseModel, "The fetchMusicApi() method didn't return expected parsing error")
            expectation.fulfill()
        }
        self.wait(for: [expectation], timeout: 5)
        
    }
    
    func test_MusicWebService_WhenEmptyURLStringProvided_ReturnsError() {
        // Arrange
        
        let expectation = self.expectation(description: "An empty request URL string expectation")
        sut = NLMusicApi(urlString: "")
        
        // Act
        sut.fetchMusicApi { musicResponseModel, error in
        // Assert
            XCTAssertEqual(error, MusicApiError.invalidRequestURLString, "The fetchMusicApi() method didn't return expected error for invalidRequestURLString error")
            XCTAssertNil(musicResponseModel, "When invalidRequestURLString error takes place the responseModel must be nil")
            expectation.fulfill()
        }
        self.wait(for: [expectation], timeout: 2)
    }
    
    func test_MusicWebService_WhenURLRequestFails_ReturnsErrorMessageWithDescription() {
        // Arrange
        let errorDescription = "A localized description of an error"
        MockURLProtocol.stubError = MusicApiError.failedRequest(description: errorDescription)
        let expectation = self.expectation(description: "Failed url request expectation")

        // Act
        sut.fetchMusicApi { musicResponseModel, error in
      
        // Assert
            XCTAssertEqual(error, MusicApiError.failedRequest(description: errorDescription))
            XCTAssertEqual(error?.localizedDescription, errorDescription)
            expectation.fulfill()
            
        }
        
        self.wait(for: [expectation], timeout: 2)
        
    }
}
