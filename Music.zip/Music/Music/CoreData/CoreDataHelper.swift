import Foundation
import CoreData

class CoreDataHelper: NSObject {
    
}
