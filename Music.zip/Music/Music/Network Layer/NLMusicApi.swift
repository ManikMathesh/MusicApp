import Foundation

enum MusicApiError: LocalizedError, Equatable {
    case invalidResponseModel
    case invalidRequestURLString
    case failedRequest(description: String)
    
    var errorDescription: String? {
        switch self {
        case .failedRequest(let description):
            return description
        case .invalidResponseModel, .invalidRequestURLString:
            return ""
        }
    }
}

protocol NLMusicApiProtocol {
    func fetchMusicApi(completionHandler: @escaping (MusicResponseModel?, MusicApiError?) -> Void)
}

class NLMusicApi: NLMusicApiProtocol {
    
    private var urlString: String
    private var urlSession: URLSession
    
    init(urlString: String, urlSession: URLSession = .shared) {
        self.urlString = urlString
        self.urlSession = urlSession
    }
    
    func fetchMusicApi(completionHandler: @escaping (MusicResponseModel?, MusicApiError?) -> Void) {
        
        guard let url = URL(string: urlString) else {
            completionHandler(nil, MusicApiError.invalidRequestURLString)
            return
        }
        
        var request = URLRequest(url:url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        let dataTask  = urlSession.dataTask(with: request) { data, response, error in
            
            if let requestError = error {
                completionHandler(nil, MusicApiError.failedRequest(description: requestError.localizedDescription))
                return
            }
            
            if let data = data, let musicResponseModel = try? JSONDecoder().decode(MusicResponseModel.self, from: data) {
                
                completionHandler(musicResponseModel, nil)
            }
            else {
                completionHandler(nil, MusicApiError.invalidResponseModel)
            }
        }
        
        dataTask.resume()
        
    }
    
}
