import Foundation

struct MusicResponseModel: Codable {
    
    let resultCount: Int
    let results: [MusicDetails]
    
}

struct MusicDetails: Codable {
    
    let trackName: String?
    let artistName: String?
    let trackPrice: Float?
    let currency: String?
    let artworkUrl30: String?
    let artworkUrl60: String?
    let artworkUrl100: String?
    let releaseDate: String?
    let trackTimeMillis: Int?
    let trackViewUrl: String?
}
