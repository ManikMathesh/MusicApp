import Foundation
import UIKit

class MainCooridnator: NSObject, Coordinator, UINavigationControllerDelegate {
    
    var childCoordinators = [Coordinator]()
    var navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {

        navigationController.delegate = self
        
        let vc = HomeViewController.instantiate()
        vc.coordinator = self
        navigationController.pushViewController(vc, animated: false)
    }
    
    func displayMusicDetails(selectedMusic: MusicTableViewCellViewModel) {
        let vc = MusicDetailViewController.instantiate()
        vc.selectedMusic = selectedMusic
        vc.coordinator = self
        navigationController.pushViewController(vc, animated: true)
    }
    
    func loadWebView(urlString: String) {
        let vc = WebViewViewController.instantiate()
        vc.urlString = urlString
        vc.coordinator = self
        navigationController.present(vc, animated: true, completion: nil)
    }

    func childDidFinish(_ child: Coordinator?) {
        for (index, coordinator) in
            childCoordinators.enumerated() {
            if coordinator === child {        //=== checks if both are referring to same memory location. It's possible only in classes.
                childCoordinators.remove(at: index)
                break
            }
        }
    }
    
    func navigationController(_ navigationController: UINavigationController, didShow viewController: UIViewController, animated: Bool) {
        guard let fromViewController = navigationController.transitionCoordinator?.viewController(forKey: .from) else {
            return
        }
        
        if  navigationController.viewControllers.contains(fromViewController) {
            return
        }
        
        if let musicDetailViewController = fromViewController as? MusicDetailViewController {
            childDidFinish(musicDetailViewController.coordinator)
        }
        
        if let webViewViewController = fromViewController as? WebViewViewController {
            childDidFinish(webViewViewController.coordinator)
        }
        
    }
   
}
