import Foundation

class MusicDetailViewModel {
    
    let artworkImageCellRowHeight = 200.0
    let musicDetailCellRowHeight = 166.0
    let numberOfRowInSection = 2


    
}
