import Foundation

class HomeViewModel {
    
    let reachability: Reachability = Reachability()
    private let appManager: AppManager = AppManager()
    
    private let musicApi: NLMusicApiProtocol
    let tableRowHeight = 80.0

    let musicList: Box<[MusicTableViewCellViewModel]> = Box([])
    let isConnectedToInternet: Box<Bool> = Box(true)

    init(musicApi: NLMusicApiProtocol = NLMusicApi(urlString: MusicSDKConstants.musicApiURL)) {
        self.musicApi = musicApi
    }
    
    func makeWebServiceCallForMusicApi() {
        
        isConnectedToInternet.value = reachability.isConnectedToNetwork()
        
        if reachability.isConnectedToNetwork() {
            self.musicApi.fetchMusicApi { [weak self] musicApiResponseModel, error in

                if let musicApiResponseModel = musicApiResponseModel {
                    
                  let beforeSortingMusicDetails = musicApiResponseModel.results.compactMap({
                        
                        MusicTableViewCellViewModel(trackName: $0.trackName ?? "-",
                                     artistName: $0.artistName ?? "-",
                                     trackPrice: $0.trackPrice ?? 0.0,
                                     currency: $0.currency ?? "USD",
                                     artworkUrl30: $0.artworkUrl30 ?? "",
                                     artworkUrl60: $0.artworkUrl60 ?? "",
                                     artworkUrl100: $0.artworkUrl100 ?? "",
                                     releaseDate: self?.appManager.getDateFromString(dateString: $0.releaseDate ?? "") ?? Date(),
                                     trackTimeMillis:  $0.trackTimeMillis ?? 0,
                                     trackViewUrl: $0.trackViewUrl ?? "")
                    })
                    
                    if let afterSortingMusicDetails = self?.sortMusicDataInDescendingOrder(musicDetailsArray: beforeSortingMusicDetails) {
                        self?.musicList.value = afterSortingMusicDetails
                    }

                }
            }
        }
        
    }
    
    
    
    func sortMusicDataInDescendingOrder(musicDetailsArray: [MusicTableViewCellViewModel]) -> [MusicTableViewCellViewModel] {
        
        var convertedMusicArray: [MusicTableViewCellViewModel] = []

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
                
        for var musicDetail in musicDetailsArray {
            if let releaseDate = appManager.getStringFromDate_yyyy_MM_dd_T_HH_mm_ssZ_Format(from: musicDetail.releaseDate)  {
                let date = dateFormatter.date(from: releaseDate)
                if let date = date {
                    musicDetail.releaseDate = date
                    convertedMusicArray.append(musicDetail)
                }
            }
        }

        let sortedMusicDataArray = convertedMusicArray.sorted(by: { $0.releaseDate?.compare($1.releaseDate!) == .orderedDescending })
        
        return sortedMusicDataArray
    }

}

struct MusicTableViewCellViewModel {
    
    private let appManager: AppManager = AppManager()

    var trackName: String?
    var artistName: String?
    var trackPrice: String?
    var currency: String?
    var artworkUrl30: String?
    var artworkUrl60: String?
    var artworkUrl100: String?
    var releaseDate: Date?
    var trackTimeMillis: String?
    var trackViewUrl: String?
    var formatedReleaseDate: String?
    
    init(trackName: String?,
         artistName: String?,
         trackPrice: Float?,
         currency: String?,
         artworkUrl30: String?,
         artworkUrl60: String?,
         artworkUrl100: String?,
         releaseDate: Date?,
         trackTimeMillis:  Int?,
         trackViewUrl: String?) {
        
        self.trackName = trackName
        self.artistName = artistName
        self.currency = currency
        
        guard let currencyCode = self.currency else { self.trackPrice = trackPrice?.description; return }
        let currencySymbol = appManager.getCurrencySymbolFromCurrencyCode(currencyCode: currencyCode)
        self.trackPrice = currencySymbol + trackPrice!.description
        
        self.artworkUrl30 = artworkUrl30
        self.artworkUrl60 = artworkUrl60
        self.artworkUrl100 = artworkUrl100
        self.releaseDate = releaseDate
        self.trackViewUrl = trackViewUrl
        
        let durationString = String(format: "%.2f", appManager.getDurationFromMilliSeconds(milliseconds: Float(trackTimeMillis!)))
        self.trackTimeMillis = "Duration: " + durationString
        
        if releaseDate != nil {
            let convertedString = (appManager.getStringFromDate_MMM_d_YYYY_Format(from: releaseDate))
            self.formatedReleaseDate = "Release date: " + (convertedString ?? "-")
        }
        
    }
}
