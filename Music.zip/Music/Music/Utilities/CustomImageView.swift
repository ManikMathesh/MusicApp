import UIKit

let imageCache = NSCache<AnyObject, AnyObject>()

class CustomImageView : UIImageView {
    
    let spinner = UIActivityIndicatorView()

    var imageUrlString :String?
    var task: URLSessionDataTask!
    
// MARK: - Load Image Method
    
    func loadImage(withUrl url: URL) {
        
        imageUrlString = url.absoluteString
        image = nil
        
        self.layer.masksToBounds = true
        self.layer.cornerRadius = 4.0

        addSpinner()
        
        if let task = task {
            task.cancel()
        }
        
        if let imageFromCache = imageCache.object(forKey: url.absoluteString as AnyObject) as? UIImage {
            image = imageFromCache
            removeSpinner()
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { (data, respone, error) in
            
            guard
            let data = data,
            let newImage = UIImage(data: data)
            else {
                print("Unable to load url --> \(url)")
                return
            }
            
            imageCache.setObject(newImage, forKey: url.absoluteString as AnyObject)
            
            DispatchQueue.main.async {
                if self.imageUrlString == url.absoluteString {
                    self.image = newImage
                    self.removeSpinner()
                }
            }
        }
        task.resume()

    }
    
// MARK: - Spinner Methods
    func addSpinner() {
        addSubview(spinner)
        spinner.color = .red
        spinner.translatesAutoresizingMaskIntoConstraints =  false
        spinner.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        spinner.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        spinner.startAnimating()
    }
    
    func removeSpinner() {
        spinner.stopAnimating()
        spinner.removeFromSuperview()
    }
    
}
