import Foundation
import UIKit

struct MusicSDKConstants {
    static let musicApiURL = "https://itunes.apple.com/search?term=rock"
    static let orangeColor = UIColor(red: 0.851, green: 0.498, blue: 0.008, alpha: 1)
}
