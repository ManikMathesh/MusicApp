import Foundation

class AppManager {
    
    
    func getCurrencySymbolFromCurrencyCode(currencyCode: String) -> String {
        let locale = NSLocale(localeIdentifier: currencyCode)
        return locale.displayName(forKey: NSLocale.Key.currencySymbol, value: currencyCode) ?? "£"
    }
    
    func getDurationFromMilliSeconds(milliseconds: Float) -> Float { // Milli seconds to Minutes
        
        if (milliseconds != 0) {
            return Float(milliseconds/60000)
        }
        return 0.0
    }
    
    func getDateFromString(dateString: String) -> Date {
        if (dateString != "") {
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "en_US_POSIX")
            dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
            guard let date = dateFormatter.date(from: dateString) else { return Date() }
            return date
        }
        return Date()
    }
    
    func getStringFromDate_MMM_d_YYYY_Format(from date: Date?) -> String? {
        let dateFormat = "MMM d, yyyy"

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat

        return getStringFromDate(from: date, dateFormatter: dateFormatter)
    }
    
    func getStringFromDate_yyyy_MM_dd_T_HH_mm_ssZ_Format(from date: Date?) -> String? {
        let dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat

        return getStringFromDate(from: date, dateFormatter: dateFormatter)
    }
    
    
    private func getStringFromDate(from date: Date?, dateFormatter: DateFormatter) -> String? {
        
        var dateString: String? = nil

        if let date = date {
            dateString = dateFormatter.string(from: date)
        }

        return dateString
    }
    
    
}
