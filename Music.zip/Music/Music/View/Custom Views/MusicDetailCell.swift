import UIKit

class MusicDetailCell: UITableViewCell {
    @IBOutlet weak var trackNameLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    
    let appManager = AppManager()

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        trackNameLabel.text = ""
        artistLabel.text = ""
        priceLabel.text = ""
        durationLabel.text = ""
        releaseDateLabel.text = ""
        self.selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK: - Setup Methods
     
    func updateData(musicDetails: MusicTableViewCellViewModel) {
        trackNameLabel.text = musicDetails.trackName
        artistLabel.text = musicDetails.artistName
        priceLabel.text = musicDetails.trackPrice
        durationLabel.text = musicDetails.trackTimeMillis
        releaseDateLabel.text = musicDetails.formatedReleaseDate
    }
    
}
