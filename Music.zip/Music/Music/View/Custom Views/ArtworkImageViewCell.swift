import UIKit

class ArtworkImageViewCell: UITableViewCell {
    
    let trackImageView = CustomImageView() // Created Custom ImageView class for loading Images
    let separatorView = UIView()

    // MARK: - Init Methods
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // MARK: - CreateView Methods
    func setupView(){
        createTrackImageView()
        createSeparatorView()
    }
    
    func createTrackImageView() {
        addSubview(trackImageView)
        
        trackImageView.contentMode = .scaleAspectFit
        trackImageView.translatesAutoresizingMaskIntoConstraints = false
        trackImageView.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
        trackImageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        trackImageView.widthAnchor.constraint(equalToConstant: 120).isActive = true
        trackImageView.heightAnchor.constraint(equalToConstant: 120).isActive = true
    }
    
    func createSeparatorView() {
        addSubview(separatorView)
        
        separatorView.backgroundColor = .darkGray
        separatorView.translatesAutoresizingMaskIntoConstraints = false
        separatorView.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor).isActive = true
        separatorView.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor).isActive = true
        separatorView.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: 0).isActive = true
        separatorView.heightAnchor.constraint(equalToConstant: 0.1).isActive = true
        
    }
    
    // MARK: - Setup Methods
    func updateData(musicDetails: MusicTableViewCellViewModel?) {
        
        if (musicDetails?.artworkUrl100 != "" || musicDetails?.artworkUrl100 != nil) {
            let imageURLString = musicDetails?.artworkUrl100
            trackImageView.loadImage(withUrl: URL(string: imageURLString!)!)
        }
        
    }
}

