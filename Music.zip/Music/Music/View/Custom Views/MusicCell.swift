import UIKit

class MusicCell: UITableViewCell {
    
    let trackImageView = CustomImageView() // Created Custom ImageView class for loading Images
    let trackLabel = UILabel()
    let artistLabel = UILabel()
    let priceLabel = UILabel()
    let separatorView = UIView()
    let appManager = AppManager()

// MARK: - Init Methods
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
// MARK: - CreateView Methods
    func setupView(){
        createTrackImageView()
        createTrackNameLabel()
        createArtistLabel()
        createPriceLabel()
        createSeparatorView()
    }
    
    func createTrackImageView() {
        addSubview(trackImageView)
        
        trackImageView.contentMode = .scaleAspectFit
        trackImageView.translatesAutoresizingMaskIntoConstraints = false
        trackImageView.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor, constant: 5).isActive = true
        trackImageView.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        trackImageView.widthAnchor.constraint(equalToConstant: 60).isActive = true
        trackImageView.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }
    
    func createTrackNameLabel() {
        addSubview(trackLabel)
        
        trackLabel.font = UIFont.boldSystemFont(ofSize: 14.0)
        trackLabel.translatesAutoresizingMaskIntoConstraints = false
        trackLabel.leadingAnchor.constraint(equalTo: trackImageView.trailingAnchor, constant: 5).isActive = true
        trackLabel.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -10).isActive = true
        trackLabel.topAnchor.constraint(equalTo: topAnchor, constant: 5).isActive = true
        trackLabel.numberOfLines = 0
    }
    
    func createArtistLabel() {
        addSubview(artistLabel)
        
        artistLabel.font = UIFont.systemFont(ofSize: 12)
        artistLabel.translatesAutoresizingMaskIntoConstraints = false
        artistLabel.leadingAnchor.constraint(equalTo: trackImageView.trailingAnchor, constant: 5).isActive = true
        artistLabel.topAnchor.constraint(equalTo: trackLabel.bottomAnchor, constant: 2).isActive = true
     //   artistLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant:20).isActive = true

    }
    
    func createPriceLabel() {
        addSubview(priceLabel)

        priceLabel.font = UIFont.boldSystemFont(ofSize: 14.0)
        priceLabel.textColor = MusicSDKConstants.orangeColor
        priceLabel.translatesAutoresizingMaskIntoConstraints = false
        priceLabel.leadingAnchor.constraint(equalTo: trackImageView.trailingAnchor, constant: 5).isActive = true
        priceLabel.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor, constant: -10).isActive = true
        priceLabel.topAnchor.constraint(equalTo: artistLabel.bottomAnchor, constant: 5).isActive = true
        
    }
    
    func createSeparatorView() {
        addSubview(separatorView)
        
        separatorView.backgroundColor = .darkGray
        separatorView.translatesAutoresizingMaskIntoConstraints = false
        separatorView.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor).isActive = true
        separatorView.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor).isActive = true
        separatorView.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor, constant: 0).isActive = true
        separatorView.heightAnchor.constraint(equalToConstant: 0.1).isActive = true
        
    }
    
// MARK: - Setup Methods
    func updateData(musicDetails: MusicTableViewCellViewModel) {
        trackImageView.loadImage(withUrl: URL(string: musicDetails.artworkUrl60!)!)
        trackLabel.text = musicDetails.trackName
        artistLabel.text = musicDetails.artistName
        priceLabel.text = musicDetails.trackPrice
    }
}

