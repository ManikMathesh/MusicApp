import UIKit

class HomeViewController: UIViewController, Storyboarded {
    
    @IBOutlet weak var tableView: UITableView!
    
    private let musicCellIdentifier = "MusicCellID"
    let viewModel:HomeViewModel = HomeViewModel()
    weak var coordinator: MainCooridnator?

    // MARK: - View Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Rock Tracks"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        navigationController?.navigationBar.tintColor = MusicSDKConstants.orangeColor


        tableView.register(MusicCell.self, forCellReuseIdentifier: musicCellIdentifier)
        tableView.accessibilityIdentifier = "HomeVCTableViewAccessID" // For UI Test
        
        tableView.refreshControl = UIRefreshControl()
        tableView.refreshControl?.addTarget(self, action: #selector(didPullToRefresh), for: .valueChanged)
        
        bindViewModel()
    }
    
    func bindViewModel() {
        viewModel.musicList.bind { [weak self] musicDetails in
            if musicDetails.count > 0 {
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
            DispatchQueue.main.async {
                self?.tableView.refreshControl?.endRefreshing()
            }
        }
        viewModel.makeWebServiceCallForMusicApi()
    }
    
    // MARK: - Userdefined Methods
        @objc func didPullToRefresh() {
            viewModel.makeWebServiceCallForMusicApi()
        }
}

// MARK: - UITableViewDataSource Methods
extension HomeViewController : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.musicList.value.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return viewModel.tableRowHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: musicCellIdentifier, for: indexPath) as! MusicCell
        cell.selectionStyle = .none
        guard viewModel.musicList.value.count > 0 else { return cell }
        let musicDetails = viewModel.musicList.value[indexPath.row]
        cell.accessibilityIdentifier = "MusicCellAccessID_\(indexPath.row)" // For UI Test
        cell.updateData(musicDetails: musicDetails)
        return cell
    }
    
    // MARK: - UITableViewDelegate Methods
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        coordinator?.displayMusicDetails(selectedMusic: viewModel.musicList.value[indexPath.row])
    }
    
}
