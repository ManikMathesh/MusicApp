import UIKit
import SafariServices

class MusicDetailViewController: UIViewController, Storyboarded {

    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var moreDetailsButton: UIButton!
    
    private let artworkImageViewCellID = "ArtworkImageViewCellID"
    private let musicDetailCellID = "MusicDetailCellID"

    weak var coordinator: MainCooridnator?
    var selectedMusic: MusicTableViewCellViewModel? =  nil
    
    let viewModel:MusicDetailViewModel = MusicDetailViewModel()

// MARK: - View Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(ArtworkImageViewCell.self, forCellReuseIdentifier: artworkImageViewCellID)
        tableView.register(UINib(nibName: "MusicDetailCell", bundle: nil), forCellReuseIdentifier: musicDetailCellID)
        self.tableView.accessibilityIdentifier = "MusicDetailVCTableViewAccessID" // For UI Test

        moreDetailsButtonUISetup()
    }
    
// MARK: - User defined Methods
    func moreDetailsButtonUISetup() {
        moreDetailsButton.backgroundColor = .clear
        moreDetailsButton.layer.borderColor = MusicSDKConstants.orangeColor.cgColor
        moreDetailsButton.layer.borderWidth = 1.0
        moreDetailsButton.layer.cornerRadius = 5.0
        
    }

    @IBAction func moreDetailsButtonAction(_ sender: Any) {
        let urlString = self.selectedMusic?.trackViewUrl
        if urlString != nil && urlString != "" {
            coordinator?.loadWebView(urlString: urlString!)
        }
    }
}

// MARK: - UITableViewDataSource Methods
extension MusicDetailViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowInSection
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return viewModel.artworkImageCellRowHeight
        }
        return viewModel.musicDetailCellRowHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: artworkImageViewCellID, for: indexPath) as! ArtworkImageViewCell
            cell.updateData(musicDetails: self.selectedMusic)
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier:musicDetailCellID, for: indexPath) as! MusicDetailCell
            if self.selectedMusic != nil {
                cell.updateData(musicDetails: self.selectedMusic!)
            }
            return cell
        }
       
        
    }
    
    
}
