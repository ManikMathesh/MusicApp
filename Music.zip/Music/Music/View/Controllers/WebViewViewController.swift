import UIKit
import WebKit

class WebViewViewController: UIViewController, Storyboarded {
    
    weak var coordinator: MainCooridnator?
    var urlString: String!
    var activityIndicator: UIActivityIndicatorView!

    let webView: WKWebView = {
        let preferences = WKPreferences()
        preferences.javaScriptEnabled = true
        let configuration = WKWebViewConfiguration()
        configuration.preferences = preferences
        let webView = WKWebView(frame: .zero, configuration: configuration)
        return webView
    }()
    
    
// MARK: - View Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView.navigationDelegate =  self
        view.addSubview(webView)
        
        createSpinner()
        loadRequest()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        webView.frame = view.bounds
    }
    
// MARK: - Userdefined Methods
    private func createSpinner() {
        activityIndicator = UIActivityIndicatorView()
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = UIActivityIndicatorView.Style.gray
        view.addSubview(activityIndicator)
    }
    
    private func loadRequest() {
        if self.urlString != nil && self.urlString != "" {
            webView.load(URLRequest(url: URL(string: self.urlString)!))
        }
    }
                  
    func showActivityIndicator(show: Bool) {
            if show {
                activityIndicator.startAnimating()
            } else {
                activityIndicator.stopAnimating()
            }
        }
}

// MARK: - WKNavigationDelegate Methods
extension WebViewViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            showActivityIndicator(show: false)
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            showActivityIndicator(show: true)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            showActivityIndicator(show: false)
        }
}
